<?php
echo"
<div id='footer'>
<hr />
<p class='foter'>&copy 2014 Guidance Interactive. All Rights Reserved</p>
</div>";
?>