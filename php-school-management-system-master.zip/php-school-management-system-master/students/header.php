<?php
echo"<div id='header'>
 <div id='guidance'>
 <p>Guidance School Students Portal</p>
 </div>
</div>";
?>