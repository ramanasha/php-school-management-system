<?php
echo"<div class='leftbar'>
<p><b>&nbsp;&nbsp;My Menu</b></p>
<ul>
<li>&nbsp;&nbsp;<a href='teacherhome.php'>Home</a></li>
<li>&nbsp;&nbsp;<a href='personal_details.php'>Personal Details</a></li>
<li>&nbsp;&nbsp;<a href='change_password.php'>Change Password</a></li>
<li>&nbsp;&nbsp;<a href='manage_class.php'>Manage Class</a></li>
<li>&nbsp;&nbsp;<a href='studentrecord.php'>Manage Students</a></li>
<li>&nbsp;&nbsp;<a href='news.php'>View News</a></li>

</ul>
</div>";

?>